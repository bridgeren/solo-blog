title: Spring Boot学习之Hello World
date: '2019-10-19 23:16:19'
updated: '2019-10-19 23:16:19'
tags: [SpringBoot]
permalink: /articles/2019/10/19/1571498179147.html
---
### 一：从零开始搭建SpringBoot应用 
[Spring官方文档](https://spring.io/guides/gs/spring-boot/)
##### 搭建方式：我采用的是基于maven搭建的，其他方式可以参考文档
1.创建目录结构  `mkdir -p src/main/java/hello `
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191018230725291.png)
2.创建pom.xml文件

```
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>org.springframework</groupId>
    <artifactId>gs-spring-boot</artifactId>
    <version>0.1.0</version>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.1.6.RELEASE</version>
    </parent>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
    </dependencies>

    <properties>
        <java.version>1.8</java.version>
    </properties>


    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>

</project>
```
3.用ide导入pom文件即可 相关依赖会自动下载的

4.创建一个web控制器
`src/main/java/hello/HelloController.java`
```
package hello;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
public class HelloController {

    @RequestMapping("/")
    public String index() {
        return "hello nickless";
    }

}
```
 

5.创建一个应用程序类·
`src/main/java/hello/Application.java`
```
package hello;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
        return args -> {

            System.out.println("Let's inspect the beans provided by Spring Boot:");

            String[] beanNames = ctx.getBeanDefinitionNames();
            Arrays.sort(beanNames);
            for (String beanName : beanNames) {
                System.out.println(beanName);
            }

        };
    }

}
```
6.至此最简单的已经搭建好了，启动试试吧
7.浏览器访问==127.0.0.1：8080==
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191018233139278.png)

### **二：Spring容器的DI和IOC[相关理解](https://blog.csdn.net/LitaVadaski/article/details/79487945)**
1.假设我们有两个类`OrderService`和`UserService`且`OrderService`依赖`UserService`那么Spring是如何进行依赖注入的呢？
比较常见的是使用`@Autowired` 但是已经不被推荐使用了，现在一般会使用==构造器==和 ==@Inject== 没有用过的同学可能会找不到这个注解，那么就需要更新一下==pom.xml==了 此处下载 [inject](https://mvnrepository.com/artifact/javax.inject/javax.inject/1)

2.`src/main/java/hello/service/OrderService`
```
package hello.service;

import javax.inject.Inject;


public class OrderService {
    private UserService userService;

    @Inject
    public OrderService(UserService userService) {
        this.userService = userService;
    }

    public void placeOrder(Integer userId, String item) {

        UserService.getUserById(userId);
    }

}


```
3·`src/main/java/hello/service/UserService`
```
package hello.service;

public class UserService {
    public static User getUserById(Integer id){
        return new User(id,"");
    }

}
```
4`.src/main/java/hello/service/UserService`
```
package hello.service;


public class User {
    Integer id;
    String name;

    public User(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

```
4更新`src/main/java/hello/HelloController.java`
```
package hello;

import hello.service.OrderService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;


@RestController
public class HelloController {
    private OrderService orderService;

    @Inject
    public HelloController(OrderService orderService) {
        this.orderService = orderService;
    }

    @RequestMapping("/")
    public String index() {
        return "hello nickless";
    }
}

```
这时你会发现`no bean of orderService`因为你还没告诉Spring如何去创建一个orderService.

5.配置`bean`
一般来说有两种方式进行配置`xml`和`使用注解`具体可以看[这个](https://www.springboottutorial.com/spring-boot-java-xml-context-configuration)
我用的是注解的方式`src/main/java/hello/configuration/JavaConfiguration`
```
package hello.configuration;

import hello.service.OrderService;
import hello.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class JavaConfiguration {
    @Bean
    public OrderService orderService() {
        return new OrderService(userService());
    }

    @Bean
    public UserService userService() {
        return new UserService();
    }
}

```
然后运行一下，测试通过

